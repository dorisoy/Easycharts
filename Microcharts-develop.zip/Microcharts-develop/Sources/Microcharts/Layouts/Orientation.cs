﻿namespace Microcharts
{
    using System;

    public enum Orientation
    {
        Default,
        Horizontal,
        Vertical,
    }
}
