﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Microcharts.Samples.Forms.macOS
{
    public partial class MyPage : ContentPage
    {
        public MyPage()
        {
            InitializeComponent();
        }
    }
}
