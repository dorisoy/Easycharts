# Microcharts

![Gallery](images/Gallery.png)

**Microcharts** is an extremely simple charting library for a wide range of platforms, with shared code and rendering for all of them!
