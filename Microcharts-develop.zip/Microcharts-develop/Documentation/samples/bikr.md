# Bikr

![Screenshot](https://github.com/aloisdeniel/Microcharts.Samples/raw/master/Bikr/screenshots.png)

A bike activity app.